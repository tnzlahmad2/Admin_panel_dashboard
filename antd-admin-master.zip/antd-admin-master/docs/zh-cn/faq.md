# 问题集锦

## 新建页面

    1. 直接从/src/pages复制一个page (会自动创建路由[umi](https://umijs.org/zh/guide/router.html#%E7%BA%A6%E5%AE%9A%E5%BC%8F%E8%B7%AF%E7%94%B1))
    2. 修改 namespace/pathToRegexp 在 model.js
    3. 修改 mock中route.js增加一条route