declare module 'data-generator-retail';
