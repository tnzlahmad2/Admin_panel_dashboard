declare module 'fakerest';
