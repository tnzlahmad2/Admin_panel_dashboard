export const types = [
    'Other',
    'Copywriting',
    'Print project',
    'UI Design',
    'Website design',
];

export const typeChoices = types.map(type => ({ id: type, name: type }));
