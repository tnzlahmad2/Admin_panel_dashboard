/* eslint-disable import/no-anonymous-default-export */
import { DealList } from './DealList';

export default {
    list: DealList,
};
