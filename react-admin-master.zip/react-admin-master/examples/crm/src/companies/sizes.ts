export const sizes = [
    { id: 1, name: '1 employee' },
    { id: 10, name: '2-9 employees' },
    { id: 50, name: '10-49 employees' },
    { id: 250, name: '50-249 employees' },
    { id: 500, name: '250 or more employees' },
];
